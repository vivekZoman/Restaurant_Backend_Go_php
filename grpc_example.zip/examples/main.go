package main

import (
	"examples/service"
	"fmt"
	"net"

	ping "examples/protos"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

func setupGRPCService() {
	port := "8080"
	addr := ":" + port

	// logger.Infof("Starting gRPC server at %s", addr)

	// Set-up our gRPC server.
	lis, err := net.Listen("tcp", addr)
	if err != nil {
		// logger.Fatalf("Failed to listen: %v", err)
	}

	s := grpc.NewServer()

	// Register our service with the gRPC server, this will tie our
	// implementation into the auto-generated interface code for our
	// protobuf definition.

	ping.RegisterPingPongServiceServer(s, service.PingPongService{})
	// Register reflection service on gRPC server.
	reflection.Register(s)
	if err := s.Serve(lis); err != nil {
		fmt.Printf("Error!")
		// logger.Fatalf("Failed to serve: %v", err)
	}
}

// Like C and many other languages this is the first function that gets called.
// func main() {
// 	setupGRPCService()
// }
