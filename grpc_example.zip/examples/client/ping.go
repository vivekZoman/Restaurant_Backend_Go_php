package client

import (
	"context"
	ping "examples/protos"
	"fmt"

	"google.golang.org/grpc"
)

func Pingpong() {
	do := grpc.WithInsecure()
	conn, err := grpc.Dial("127.0.0.1:8080", do)
	if err != nil {
		fmt.Printf("Error: %v", err.Error())
	}
	c := ping.NewPingPongServiceClient(conn)
	ctx := context.TODO()

	req := &ping.Request{
		Ping: "Ping",
	}
	res, errRes := c.Ping(ctx, req)
	if errRes != nil {
		fmt.Println(errRes.Error())
	}
	fmt.Println(res.GetPong())
}
