package main

import "examples/client"

func main() {
	client.Pingpong()
}
