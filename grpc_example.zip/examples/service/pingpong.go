package service

import (
	"context"
	"fmt"

	ping "examples/protos"
)

type PingPongService struct {
}

// Read more about context.Context from godocs
func (s PingPongService) Ping(ctx context.Context, req *ping.Request) (res *ping.Response, err error) {
	fmt.Printf("Request is: %v \n", req.GetPing())
	res = &ping.Response{
		Pong: "Hello, world!",
	}

	return
}
