<?php

// autoload.php loads
require 'vendor/autoload.php';

$client = new Proto\ServicesClient('localhost:8080',[
    'credentials' => Grpc\ChannelCredentials::createInsecure(),
]);

// $_SERVER stores the method type and the request type ....

$request = $_SERVER['PATH_INFO'];
$method = $_SERVER['REQUEST_METHOD'];

// different different functions called according to the functionallity defined..

if ( $method=='POST' && $request=='/add'){
    addNewRestaurant($client);
}
else if($method=='GET' && $request=='/get'){
    getAllRestaurants($client);
}
else if($method=='PUT' && $request=='/update'){
    updateRestaurant($client,$request);
}
else if($method=="DELETE" && $request=='/delete'){
    deleteRestaurant($client,$request);
}
else{
// no valid reqest found....

    http_response_code(400);
    echo json_encode(array("error" => "404 bad request ! Not a valid request.."));
}





// this function is used to decode the data from a restro object and convert it to the 
// JSON object...
function convertRestroObjectToJsonObject($coded_restaurant){
    $restaurant = array();
    $restaurant["Name"] = $coded_restaurant->getName();
    $restaurant["Adress"] = $coded_restaurant->getAdress();
    $restaurant["Id"] = $coded_restaurant->getId();
    $restaurant["Cuisine"] = $coded_restaurant->getCuisine();
    $restaurant["Ratings"] = $coded_restaurant->getRatings();
    return $restaurant;
}

// this function is used reverse of above function and used to make a JSON object 
// into a restro Object defined in restaurant.proto file..

// all these functions are defined in pb.go file and are according to the functionality that we have given to them.

function convertJsonToRestroObject($restaurant){
    $request = new Proto\Restro();
    
    $request->setName(array_key_exists("Name",$restaurant)?$restaurant["Name"]:"");
    $request->setAdress(array_key_exists("Adress",$restaurant)?$restaurant["Adress"]:"");
    $request->setId(array_key_exists("Id",$restaurant)?$restaurant["Id"]:0);
    $request->setCuisine(array_key_exists("Cuisine",$restaurant)?$restaurant["Cuisine"]:"");
    $request->setRatings(array_key_exists("Ratings",$restaurant)?$restaurant["Ratings"]:"");
    return $request;
}


// this function is called when rest api is hit for add a new restaurant...
// this function is called when we get a method type 'POST' and create parameter with it..

function addNewRestaurant($client){
    $requestBody = file_get_contents('php://input');    //get POST request body
    $requestBody = json_decode($requestBody,true);  //json object to php dictionary object..

    // checking for the last occured error if any..

    if(json_last_error() != JSON_ERROR_NONE){
        http_response_code(400);
        echo json_encode(array("flag"=>"Invalid json data"));
        return;
    }

    $requestBody["Id"] = 0; //since we are creating new restaurant and it is given by system and it is auto incremented,..
   
    $request = convertJsonToRestroObject($requestBody);

    list($resp, $status) = $client->Post($request)->wait();
    if($resp->getFlag()=="True")
        http_response_code(201);
    else
        http_response_code(400);

    echo json_encode(array("Flag" => $resp->getFlag()));
}

// this function is called when rest api is hit for reading all the existing restaurants...
// this function is called when we get a method type 'GET' and get parameter with it..


function getAllRestaurants($client){
    //echo "hello i am here....";

    // parameter that has to be given in the function is defined as a type that is given by us in proto file..
    $empParam = new Proto\GetAllRestaurant();
    
    // list of all restaurants as array is assigned to restaurants...
    list($restaurants,$status) = $client->GetAll($empParam)->wait();
    
    $restaurants = $restaurants->GetRestaurant();

    $all_restros = array();
    foreach($restaurants as $restaurant){
        $decoded_restaurant = convertRestroObjectToJsonObject($restaurant);
        array_push($all_restros,$decoded_restaurant);
    }
    http_response_code(200);
    echo json_encode($all_restros);
}

// this function is called when rest api is hit for Updating any of the existing restaurants...
// this function is called when we get a method type 'PUT' and update parameter with it..


function updateRestaurant($client){
    $requestBody = file_get_contents('php://input');
    $requestBody = json_decode($requestBody,true);  //json object to php dictionary object

    if(json_last_error() != JSON_ERROR_NONE){
        http_response_code(400);
        echo json_encode(array("Status"=>"Invalid json data"));
        return;
    }
    $request = convertJsonToRestroObject($requestBody);

    list($resp,$status) = $client->Edit($request)->wait();
    if($resp->getFlag()=="True"){
        http_response_code(200);
        echo json_encode(array("Status" => "Restaurant Updated")); // successfully updated..
    }
    else{
        http_response_code(400);
        echo json_encode(array("Status"=>"Unable to proceed! some error occured..."));
    }
}

// this function is called when rest api is hit for Deleting any of the existing restaurants...
// this function is called when we get a method type 'DELETE' and /delete parameter with it..


function deleteRestaurant($client){

    $requestBody = file_get_contents('php://input');
    $requestBody = json_decode($requestBody,true);  //json object to php dictionary object
    
    if(json_last_error() != JSON_ERROR_NONE){
        http_response_code(400);
        echo json_encode(array("Status"=>"Invalid json data")); // if some error occured..
        return;
    }

    $request = convertJsonToRestroObject($requestBody);

    list($resp,$status) = $client->Delete($request)->wait();
    if($resp->getFlag()=="True"){
        http_response_code(200);
        echo json_encode(array("Status" => "Restaurant Deleted Succesfully"));
    }
    else{
        http_response_code(400);
        echo json_encode(array("Status"=>"Unable to Delete! Some error occured"));
    }   
}


// $request = $_SERVER['PATH_INFO'];
// $method = $_SERVER['REQUEST_METHOD'];

// if ( $method=='POST' && $request=='/create'){
//     runCreateRestaurant($client);
// }
// else if($method=='GET' && $request=='/read'){
//     runGetRestaurant($client);
// }
// else if($method=='PUT' && $request=='/update'){
//     runUpdateRestaurant($client,$request);
// }
// else if($method=="DELETE" && $request=='/delete'){
//     runDeleteRestaurant($client,$request);
// }
// else{
//     http_response_code(400);
//     echo json_encode(array("error" => "404 bad request"));
// }
