// Follow these steps to run this backend server successfully...

1. run the server first by running the command from server directory :
               $ go run main.go
    
2. Run your apache server in the project directory or normal php server and go to localhost/index.php/get,,,,it will give list of all the existing restaurants.

3. Use "Postman" or equivalent tool to call various requests...