<?php
// GENERATED CODE -- DO NOT EDIT!

namespace Proto;

/**
 */
class ServicesClient extends \Grpc\BaseStub {

    /**
     * @param string $hostname hostname
     * @param array $opts channel options
     * @param \Grpc\Channel $channel (optional) re-use channel object
     */
    public function __construct($hostname, $opts, $channel = null) {
        parent::__construct($hostname, $opts, $channel);
    }

    /**
     * @param \Proto\GetAllRestaurant $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function GetAll(\Proto\GetAllRestaurant $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/proto.Services/GetAll',
        $argument,
        ['\Proto\GetAllRestros', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \Proto\Restro $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function GetOne(\Proto\Restro $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/proto.Services/GetOne',
        $argument,
        ['\Proto\Response', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \Proto\Restro $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function Post(\Proto\Restro $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/proto.Services/Post',
        $argument,
        ['\Proto\Response', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \Proto\Restro $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function Edit(\Proto\Restro $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/proto.Services/Edit',
        $argument,
        ['\Proto\Response', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \Proto\Restro $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function Delete(\Proto\Restro $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/proto.Services/Delete',
        $argument,
        ['\Proto\Response', 'decode'],
        $metadata, $options);
    }

}
