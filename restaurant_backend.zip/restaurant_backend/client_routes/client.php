<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

// we have to initialise new slim App....

$app = new \Slim\App;

// This is our client file written in PHP, 


// this client is basically the connection over localhost...
$client = new Proto\ServicesClient('localhost:8080',[
    'credentials' => Grpc\ChannelCredentials::createInsecure(),
]);

// this function is used to convert and map the response object to the php object.

function mapResponseObjectToPHPObject($response) {
    $obj = [
        // "rest_id" => $response->getRestId(),

        "id" => $response->getId(),
        "name" => $response->getName(),
        "ratings" => $response->getRatings(),
        "adress" => $response->getAdress(),
        "cuisine" => $response->getCuisine(),
    ];
    return $obj;
}
function mapResponseFlagToPHPObject($response){
    $obj = [
    "flag" => $response->getFlag(),
    ];

    return obj;
}
// this function is used to convert and map the request object to the restro object.

function mapRequestToRestaurantObject($request) {
    $restaurant = new Proto\Restro;
    $restaurant->setId($request['id']);
    $restaurant->setName($request['name']);
    $restaurant->setRatings($request['ratings']);
    $restaurant->setAdress($request['adress']);
    $restaurant->setCuisine($request['cuisine']);
    return $restaurant;
}

// Now we are going to write the app routes for the various features, that are required using the following functions..,
// for the features(requests) like get(), post(), edit(), delete();

$app->group('/api', function () use ($app){
    echo "now i am in group functiopn.....";

    $app->get('/restaurants', function (Request $request, Response $response, array $args) {
        echo "aaja aaja dil nichode ......aaaja aajaaja ajjajjaajajaj aja";

       
        global $client;

    
        $empty_parameter = new Proto\GetAllRestaurant;
        
        list($restaurants, $status) = $client->GetAll($empty_parameter)->wait();
        $restaurants = $restaurants->GetRestaurant();
        
        $final = [];
        foreach($restaurants as $rest) {
            $final[] = mapResponseObjectToPHPObject($rest);
        }
        return $response->withJson($final);
    });
    
    $app->get('/restaurant/{id}', function (Request $request, Response $response, array $args) {
        global $client;
    
        $rest_id = new Proto\Restro;
        $rest_id->setId($args['id']);
    
        list($res, $status) = $client->GetOne($rest_id)->wait();
        
        $final = mapResponseFlagToPHPObject($res);
        return $response->withJson($final);
    });
    
    $app->post('/restaurant', function(Request $request, Response $response, array $args){
        global $client;
    
        $req = $request->getParsedBody();
        if($req != null){
        $restaurant = mapRequestToRestaurantObject($req);
         }
    
        list($res, $status) = $client->Post($restaurant)->wait();
    
        // $final = ['Name' => $res->getName()];
        $final = mapResponseFlagToPHPObject($res);
    
        return $response->withJson($final);
    });
    
    $app->put('/restaurant', function (Request $request, Response $response, array $args) {
        global $client;
    
        $req = $request->getParsedBody();
        $restaurant = mapRequestToRestaurantObject($req);
        // $restaurant->setRestId($r['rest_id']);
    
        list($res, $status) = $client->Edit($restaurant)->wait();
    
        // $final = ['status' => $res->getSuccess()];
        $final = mapResponseFlagToPHPObject($res);
        return $response->withJson($final);
    });
    
    $app->delete('/restaurant/{id}', function (Request $request, Response $response, array $args) {
        global $client;
    
        // $req = new Proto\Restaurant;
        // $restaurant = mapRequestToRestaurantObject($req);

        $rest_id = new Proto\Restro;
        $rest_id->setName($args['id']);
    
        list($res, $status) = $client->Delete($rest_id)->wait();
        
        // $final = ['status' => $res->getSuccess()];
        $final = mapResponseFlagToPHPObject($res);
        return $response->withJson($final);
    });
});

 




// if($method_type == 'POST' && $request == '/create'){
// }else if($method_type == 'GET' && $request == '/read'){
// }else if($method_type == 'PUT' && $request == '/update'){
// }else if($method_type == 'DELETE' && $request == '/delete'){
// }else{
//     echo "No valid resuest found... Please give a valid request!!";
// }
