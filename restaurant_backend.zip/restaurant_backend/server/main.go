package main
// this is our main go server which is reponsible for all the server side operations and DB operations...

import (
	pb "Sites/proto"
	"context"
	"database/sql"
	"fmt"
	"log"
	"net"

	_ "github.com/go-sql-driver/mysql"
	"google.golang.org/grpc"
)

var db *sql.DB

type restaurantTypeServer struct{}


// init function is used to make the connection with the database and anyother settt.

func init() {
	var err error
	db, err = sql.Open("mysql", "restro:Development@123@/restroDB")
	if err != nil {
		log.Fatal(err)
	} else {
		fmt.Println("Data base is connected ...carry on")
	}

}

// name of data base is "restaurantsDetails".....
// this function is reponsible to return the list of all the restaurants existing in the database...

func (s *restaurantTypeServer) GetAll(ctx context.Context, request *pb.GetAllRestaurant) (*pb.GetAllRestros, error) {

	// arrray of the restaurants.
	restaurants := []*pb.Restro{}

	rows, err := db.Query("select * from restaurantsDetails")

	if err != nil {
		if err == sql.ErrNoRows {
			fmt.Println("No Restaurants Found!!!!!")
			// return proto.Response{Restaurant : restaurants},nil
		}
		log.Fatalf("Error in line 40....main.go")
	}

	defer rows.Close()

	for rows.Next() {
		// getting the particular restaurant;;;;;;
		restro := &pb.Restro{}
		err := rows.Scan(&restro.Id, &restro.Name, &restro.Adress, &restro.Ratings, &restro.Cuisine)

		if err != nil {
			log.Fatal("Error in line 51...main.go")
		}
		restaurants = append(restaurants, restro)

	}
	if err = rows.Err(); err != nil {
		log.Fatal("Error in rows.err at line ....58")
	}
	return &pb.GetAllRestros{Restaurant: restaurants}, nil
}

// this function is reponsible to return the specific restaurant existing in the database with the given details...


func (s *restaurantTypeServer) GetOne(ctx context.Context, request *pb.Restro) (*pb.Response, error) {
	id := request.GetId()
	restaurant := pb.Restro{}

	err := db.QueryRow("Select * From restaurantsDetails where id = ?", id).Scan(&restaurant.Id, &restaurant.Name, &restaurant.Ratings, &restaurant.Cuisine, &restaurant.Adress)

	if err != nil {
		fmt.Printf("There is some error at line number 71 at main.go..,.")
		return nil, err
	}

	return &pb.Response{Flag: "True"}, nil
}

// this function is reponsible for adding a new restaurant in the database...

func (s *restaurantTypeServer) Post(ctx context.Context, request *pb.Restro) (*pb.Response, error) {
	id, name, rating, address, cuisine := request.GetId(), request.GetName(), request.GetRatings(), request.GetAdress(), request.GetCuisine()
	//log.Println(*request)
	db.Query("INSERT INTO restaurantsDetails(id,name,ratings,adress,cuisine) VALUES(?,?,?,?,?)", id, name, rating, address, cuisine)

	return &pb.Response{Flag: "True"}, nil

	//return &pb.Restro{Name : restaurant.Name, Adress : restaurant.Adress, Ratings : restaurant.Ratings, Cuisine : restaurant.Cuisine},nil
}

// this function is reponsible to update the existing restaurant with the given new details....


func (s *restaurantTypeServer) Edit(ctx context.Context, request *pb.Restro) (*pb.Response, error) {
	id, name, rating, address, cuisine := request.GetId(), request.GetName(), request.GetRatings(), request.GetAdress(), request.GetCuisine()

	db.Query("UPDATE restaurantsDetails SET ratings = ? , adress = ? , cuisine = ? , name = ? where id = ?",
		rating, address, cuisine, name, id)

	return &pb.Response{Flag: "True"}, nil

}


// this function is reponsible to Delete the existing restaurant with the given restaurant details,



func (s *restaurantTypeServer) Delete(ctx context.Context, request *pb.Restro) (*pb.Response, error) {
	id := request.GetId()

	db.Query("DELETE FROM restaurantsDetails WHERE id = ?", id)

	return &pb.Response{Flag: "True"}, nil
}


//  main function, which is responsible for the setup of the grpc server.....

func main() {
	listener, err := net.Listen("tcp", fmt.Sprintf(":%d", 8080))
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()
	pb.RegisterServicesServer(grpcServer, &restaurantTypeServer{})

	if err := grpcServer.Serve(listener); err != nil {
		log.Fatalf("failed to serve: %s", err)
	}

}
